<?php 
$stream = $_GET['stream'];
$height = $_GET['vh'];
$width = $_GET['vw'];
?>
<html>
  <head>
    <title><?php echo "$stream";?></title>
      <script src="video.js"></script>
       <script src="videojs.hls.min.js"></script>
       <link rel="stylesheet" type="text/css" href="video-js.css">
       <link rel="stylesheet" href="videojs.socialShare.css">
       <script src="videojs.socialShare.js"></script>
  </head>

  <body>
<video id=example-video height="<?php echo "$height";?>" width="<?php echo "$width";?>" class="video-js vjs-default-skin" controls>
  <source
     src="http://52.143.143.14:8080/hls/<?php echo "$stream";?>.m3u8"
     type="application/x-mpegURL">
</video>
<script>
	var player = videojs('example-video');

player.play();
  'use strict';
  
  var video = videojs('example-video');
  video.socialShare({
    facebook: { // optional, includes a Facebook share button (See the [Facebook documentation](https://developers.facebook.com/docs/sharing/reference/share-dialog) for more information)
      shareUrl: '', // optional, defaults to window.location.href
      shareImage: '', // optional, defaults to the Facebook-scraped image
      shareText: ''
    },
    twitter: { // optional, includes a Twitter share button (See the [Twitter documentation](https://dev.twitter.com/web/tweet-button/web-intent) for more information)
      handle: '', // optional, appends `via @handle` to the end of the tweet 
      shareUrl: '', // optional, defaults to window.location.href
      shareText: '' 
    }
  });
	</script>

	  </body>
</html>
